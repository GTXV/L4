#include <pybind11/pybind11.h>
#include <pybind11/stl.h>
#include <pybind11/functional.h>
#include "afc_multixfer_recursive.cpp"

namespace py = pybind11;

class AfcApiWrapper {
    std::unique_ptr<AfcSession> sess;
public:
    AfcApiWrapper() = default;

    py::object __enter__() {
        sess = std::make_unique<AfcSession>();
        if (!sess->ok) {
            throw std::runtime_error("Failed to create AFC session: " + sess->err);
        }
        return py::cast(this);
    }

    void __exit__(py::object exc_type, py::object exc_value, py::object traceback) {
        sess.reset();
    }

    bool is_ok() const { return sess && sess->ok; }
    std::string get_error() const { return (sess) ? sess->err : "Not connected"; }

    std::vector<std::map<std::string, py::object>> list_dir(const std::string& path) {
        if (!is_ok()) throw std::runtime_error("AFC session not ready");
        auto names = afc_listdir(sess->afc, path);
        std::vector<std::map<std::string, py::object>> results;
        for (const auto& name : names) {
            std::string full_path = join_posix(path, name);
            auto ifmt = afc_get_ifmt(sess->afc, full_path);
            if (!ifmt) continue;

            std::map<std::string, py::object> entry;
            entry["name"] = py::cast(name);
            entry["path"] = py::cast(full_path);
            entry["is_dir"] = py::cast(*ifmt == "S_IFDIR");
            if (*ifmt != "S_IFDIR") {
                if (auto size = afc_get_size(sess->afc, full_path)) {
                    entry["size"] = py::cast(*size);
                }
            }
            results.push_back(entry);
        }
        return results;
    }

    std::string make_dir(const std::string& path, const std::string& name) {
        if (!is_ok()) throw std::runtime_error("AFC session not ready");
        std::string full_path = join_posix(path, name);
        auto r = afc_mkdirs(sess->afc, full_path);
        if (r != AFC_E_SUCCESS) {
            throw std::runtime_error("Failed to create directory: " + full_path);
        }
        return full_path;
    }

    void delete_path(const std::string& path) {
        if (!is_ok()) throw std::runtime_error("AFC session not ready");
        if (afc_remove_path(sess->afc, path.c_str()) != AFC_E_SUCCESS) {
            throw std::runtime_error("Failed to delete: " + path);
        }
    }

    std::string rename(const std::string& path, const std::string& new_name) {
        if (!is_ok()) throw std::runtime_error("AFC session not ready");
        std::string parent = dirname_posix(path);
        std::string new_path = join_posix(parent, new_name);
        if (afc_rename_path(sess->afc, path.c_str(), new_path.c_str()) != AFC_E_SUCCESS) {
            throw std::runtime_error("Failed to rename: " + path + " to " + new_name);
        }
        return new_path;
    }

    std::string upload(const std::string& local_path, const std::string& remote_dir, py::object progress_cb) {
        if (!is_ok()) throw std::runtime_error("AFC session not ready");
        
        fs::path p(local_path);
        std::string remote_path = join_posix(remote_dir, p.filename().string());

        Config cfg; // default config
        Task task{local_path, remote_path, true};

        std::string parent = dirname_posix(task.dst);
        if (afc_mkdirs(sess->afc, parent) != AFC_E_SUCCESS) {
            throw std::runtime_error("mkdir failed: " + parent);
        }

        uint64_t start_off = 0;
        if (cfg.resume) {
            if (auto sz = afc_get_size(sess->afc, task.dst)) start_off = *sz;
        }

        uint64_t h = 0;
        afc_error_t r = afc_file_open(sess->afc, task.dst.c_str(), AFC_FOPEN_WRONLY, &h);
        if (r != AFC_E_SUCCESS) {
            r = afc_file_open(sess->afc, task.dst.c_str(), AFC_FOPEN_WR, &h);
            if (r != AFC_E_SUCCESS) throw std::runtime_error("open remote failed: " + task.dst);
        }
        if (start_off > 0) afc_file_seek(sess->afc, h, (int64_t)start_off, SEEK_SET);

        std::ifstream in(task.src, std::ios::binary);
        if (!in) { afc_file_close(sess->afc, h); throw std::runtime_error("open local failed: " + task.src); }
        in.seekg(0, std::ios::end); uint64_t total = (uint64_t)in.tellg();
        if (start_off > total) start_off = 0;
        in.seekg((std::streamoff)start_off, std::ios::beg);

        std::vector<char> buf; buf.resize(cfg.chunk_size);
        uint64_t done = start_off;

        while (in) {
            in.read(buf.data(), (std::streamsize)buf.size());
            std::streamsize rn = in.gcount();
            if (rn <= 0) break;
            
            uint32_t written = 0;
            r = afc_file_write(sess->afc, h, buf.data(), (uint32_t)rn, &written);
            if (r != AFC_E_SUCCESS) {
                 afc_file_close(sess->afc, h);
                 throw std::runtime_error("afc_file_write failed");
            }
            done += written;
            if (progress_cb && total > 0) {
                progress_cb(py::cast((int)(100.0 * done / total)));
            }
        }
        afc_file_close(sess->afc, h);
        if (progress_cb) progress_cb(py::cast(100));
        return remote_path;
    }

    std::string download(const std::string& remote_path, const std::string& local_dir, py::object progress_cb) {
        if (!is_ok()) throw std::runtime_error("AFC session not ready");

        fs::path local_p = fs::path(local_dir) / fs::path(remote_path).filename();
        std::string local_path = local_p.string();

        Config cfg; // default config
        Task task{remote_path, local_path, false};

        auto totalOpt = afc_get_size(sess->afc, task.src);
        if (!totalOpt) throw std::runtime_error("cannot get size: " + task.src);
        uint64_t total = *totalOpt;

        fs::create_directories(fs::path(task.dst).parent_path());

        uint64_t h=0; 
        if (afc_file_open(sess->afc, task.src.c_str(), AFC_FOPEN_RDONLY, &h) != AFC_E_SUCCESS) {
            throw std::runtime_error("open remote failed: " + task.src);
        }

        std::fstream out(task.dst, std::ios::out | std::ios::binary | std::ios::trunc);
        if (!out) { afc_file_close(sess->afc, h); throw std::runtime_error("open local failed: " + task.dst); }

        std::vector<char> buf; buf.resize(cfg.chunk_size);
        uint64_t done = 0;

        while (done < total) {
            uint32_t want = (uint32_t)std::min<uint64_t>(buf.size(), total - done);
            uint32_t rn = 0;
            auto r = afc_file_read(sess->afc, h, buf.data(), want, &rn);
            if (r != AFC_E_SUCCESS) { afc_file_close(sess->afc, h); throw std::runtime_error("read failed: " + task.src); }
            if (rn == 0) break;
            out.write(buf.data(), rn);
            if (!out) { afc_file_close(sess->afc, h); throw std::runtime_error("write local failed: " + task.dst); }
            done += rn;
            if (progress_cb && total > 0) {
                progress_cb(py::cast((int)(100.0 * done / total)));
            }
        }
        afc_file_close(sess->afc, h);
        if (progress_cb) progress_cb(py::cast(100));
        return local_path;
    }

    std::vector<std::string> roots() {
        return {"/"};
    }

    void close() {
        sess.reset();
    }
};

PYBIND11_MODULE(afc, m) {
    py::class_<AfcApiWrapper>(m, "AfcApi")
        .def(py::init<>())
        .def("__enter__", &AfcApiWrapper::__enter__)
        .def("__exit__", &AfcApiWrapper::__exit__)
        .def("is_ok", &AfcApiWrapper::is_ok)
        .def("get_error", &AfcApiWrapper::get_error)
        .def("list_dir", &AfcApiWrapper::list_dir)
        .def("make_dir", &AfcApiWrapper::make_dir)
        .def("delete_path", &AfcApiWrapper::delete_path)
        .def("rename", &AfcApiWrapper::rename)
        .def("upload", &AfcApiWrapper::upload)
        .def("download", &AfcApiWrapper::download)
        .def("roots", &AfcApiWrapper::roots)
        .def("close", &AfcApiWrapper::close);
}