
from setuptools import setup, Extension
import pybind11
import subprocess

# Use pkg-config to get compiler and linker flags
cflags = subprocess.check_output(['pkg-config', '--cflags', 'libimobiledevice-1.0', 'libplist-2.0']).decode('utf-8').strip().split()
libs = subprocess.check_output(['pkg-config', '--libs', 'libimobiledevice-1.0', 'libplist-2.0']).decode('utf-8').strip().split()

ext_modules = [
    Extension(
        'afc',
        ['pybind11_wrapper.cpp'],
        include_dirs=[
            pybind11.get_include(),
        ],
        extra_compile_args=['-std=c++17'] + cflags,
        extra_link_args=libs,
        language='c++'
    ),
]

setup(
    name='afc',
    version='0.1',
    author='Gemini',
    description='AFC wrapper for file transfer',
    ext_modules=ext_modules,
)
