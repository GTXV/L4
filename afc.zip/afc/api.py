import typing as T
from dataclasses import dataclass

# This is the C++ extension module that will be built.
import afc

@dataclass
class RemoteEntry:
    name: str
    path: str
    is_dir: bool
    size: int = 0
    mtime: T.Optional[float] = None  # epoch seconds


class AfcAPI:
    """API for interacting with a device via AFC."""

    def __init__(self):
        self._afc_api = afc.AfcApi()
        self._session = None

    def __enter__(self):
        self._session = self._afc_api.__enter__()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self._afc_api.__exit__(exc_type, exc_val, exc_tb)
        self._session = None

    def list_dir(self, path: str) -> T.List[RemoteEntry]:
        """Lists the contents of a directory."""
        if not self._session:
            raise RuntimeError("Session not active. Use 'with' statement.")
        entries = self._session.list_dir(path)
        return [RemoteEntry(**e) for e in entries]

    def make_dir(self, path: str, name: str) -> str:
        """Creates a directory."""
        if not self._session:
            raise RuntimeError("Session not active. Use 'with' statement.")
        return self._session.make_dir(path, name)

    def delete_path(self, path: str) -> None:
        """Deletes a file or directory."""
        if not self._session:
            raise RuntimeError("Session not active. Use 'with' statement.")
        self._session.delete_path(path)

    def rename(self, path: str, new_name: str) -> str:
        """Renames a file or directory."""
        if not self._session:
            raise RuntimeError("Session not active. Use 'with' statement.")
        return self._session.rename(path, new_name)

    def upload(self, local_path: str, remote_dir: str, progress_cb: T.Callable[[int], None] = None) -> str:
        """Uploads a file."""
        if not self._session:
            raise RuntimeError("Session not active. Use 'with' statement.")
        return self._session.upload(local_path, remote_dir, progress_cb)

    def download(self, remote_path: str, local_dir: str, progress_cb: T.Callable[[int], None] = None) -> str:
        """Downloads a file."""
        if not self._session:
            raise RuntimeError("Session not active. Use 'with' statement.")
        return self._session.download(remote_path, local_dir, progress_cb)

    def roots(self) -> T.List[str]:
        """Returns the root directories."""
        if not self._session:
            raise RuntimeError("Session not active. Use 'with' statement.")
        return self._session.roots()

    def close(self) -> None:
        """Closes the connection."""
        if self._session:
            self._afc_api.close()


if __name__ == '__main__':
    # Example usage:
    # You will need to build the C++ extension first.
    # python setup.py build_ext --inplace

    print("Attempting to connect to device...")
    try:
        with AfcAPI() as api:
            print("Successfully connected to device.")
            print("Root directories:", api.roots())
            
            remote_path = "/"
            print(f"Listing contents of: {remote_path}")
            try:
                for entry in api.list_dir(remote_path):
                    print(f"  - {'[D]' if entry.is_dir else '[F]'} {entry.name} ({entry.size} bytes)")
            except Exception as e:
                print(f"Error listing directory: {e}")

    except RuntimeError as e:
        print(f"Error: {e}")
    except ImportError:
        print("Error: Could not import the 'afc' module.")
        print("Please make sure you have built the C++ extension by running:")
        print("python setup.py build_ext --inplace")
