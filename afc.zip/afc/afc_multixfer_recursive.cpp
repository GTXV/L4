// afc_multixfer_recursive.cpp
// Multi-file AFC transfer with recursive upload/download (-r / --recursive)
// Build (example):
//   g++ -std=c++17 afc_multixfer_recursive.cpp -o afc_multixfer \
//     $(pkg-config --cflags --libs libimobiledevice-1.0 libplist-2.0) -lpthread

#include <atomic>
#include <chrono>
#include <condition_variable>
#include <cstdint>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <mutex>
#include <optional>
#include <queue>
#include <string>
#include <thread>
#include <vector>

namespace fs = std::filesystem;

extern "C" {
#include <libimobiledevice/idevice.h>
#include <libimobiledevice/lockdown.h>
#include <libimobiledevice/afc.h>
#include <plist/plist.h>
}

// ---------- small utils ----------
static std::string human_size(uint64_t v) {
    const char* units[] = {"B","KB","MB","GB","TB"};
    int i = 0; double d = (double)v;
    while (d >= 1024.0 && i < 4) { d /= 1024.0; ++i; }
    char buf[64]; std::snprintf(buf, sizeof(buf), i?"%.2f %s":"%.0f %s", d, units[i]);
    return buf;
}

static std::string to_posix_path(std::string s) {
#ifdef _WIN32
    for (auto &ch : s) if (ch == '\\') ch = '/';
#endif
    // collapse duplicate '/'
    std::string out; out.reserve(s.size());
    bool prev_slash=false;
    for (char c : s) {
        if (c == '/') { if (!prev_slash) out.push_back('/'); prev_slash=true; }
        else { out.push_back(c); prev_slash=false; }
    }
    return out.empty()?std::string("/"):out;
}

static std::string join_posix(const std::string& a, const std::string& b) {
    if (a.empty()) return to_posix_path(b);
    std::string A = to_posix_path(a);
    std::string B = to_posix_path(b);
    if (A.back() != '/') A.push_back('/');
    return A + B;
}

static std::string dirname_posix(std::string p) {
    p = to_posix_path(p);
    if (p == "/") return "/";
    auto pos = p.find_last_of('/');
    if (pos == std::string::npos) return "/";
    if (pos == 0) return "/";
    return p.substr(0, pos);
}

// ---------- AFC session RAII ----------
struct AfcSession {
    bool ok{false};
    std::string err;
    idevice_t dev{nullptr};
    lockdownd_client_t lck{nullptr};
    afc_client_t afc{nullptr};

    AfcSession(const char* udid = nullptr) {
        idevice_error_t e = idevice_new(&dev, udid);
        if (e != IDEVICE_E_SUCCESS) { err = "idevice_new failed"; return; }
        if (lockdownd_client_new_with_handshake(dev, &lck, "afc_multixfer")) { err = "lockdownd handshake failed"; return; }
        lockdownd_service_descriptor_t svc = nullptr;
        if (lockdownd_start_service(lck, "com.apple.afc", &svc)) { err = "start_service afc failed"; return; }
        if (afc_client_new(dev, svc, &afc)) { err = "afc_client_new failed"; return; }
        lockdownd_service_descriptor_free(svc);
        ok = true;
    }
    ~AfcSession() {
        if (afc) { afc_client_free(afc); afc = nullptr; }
        if (lck) { lockdownd_client_free(lck); lck = nullptr; }
        if (dev) { idevice_free(dev); dev = nullptr; }
    }
};

// ---------- AFC helpers ----------
static std::optional<uint64_t> afc_get_size(afc_client_t afc, const std::string& path) {
    char **info = nullptr;
    if (afc_get_file_info(afc, path.c_str(), &info) != AFC_E_SUCCESS || !info) return std::nullopt;
    uint64_t size = 0; bool found=false;
    for (size_t i=0; info[i] && info[i+1]; i+=2) {
        std::string k = info[i]; std::string v = info[i+1];
        if (k == "st_size") { size = std::strtoull(v.c_str(), nullptr, 10); found=true; break; }
    }
    afc_dictionary_free(info);
    if (!found) return std::nullopt; else return size;
}

static std::optional<std::string> afc_get_ifmt(afc_client_t afc, const std::string& path) {
    char **info = nullptr;
    if (afc_get_file_info(afc, path.c_str(), &info) != AFC_E_SUCCESS || !info) return std::nullopt;
    std::optional<std::string> out;
    for (size_t i=0; info[i] && info[i+1]; i+=2) {
        if (std::string(info[i]) == "st_ifmt") { out = std::string(info[i+1]); break; }
    }
    afc_dictionary_free(info);
    return out;
}

static bool afc_exists(afc_client_t afc, const std::string& path) {
    char **info = nullptr;
    if (afc_get_file_info(afc, path.c_str(), &info) != AFC_E_SUCCESS) return false;
    if (!info) return false;
    afc_dictionary_free(info);
    return true;
}

static bool afc_is_dir(afc_client_t afc, const std::string& path) {
    auto t = afc_get_ifmt(afc, path);
    if (!t) return false;
    return (*t == "S_IFDIR");
}

static afc_error_t afc_mkdirs(afc_client_t afc, const std::string& path) {
    std::string p = to_posix_path(path);
    if (p == "/") return AFC_E_SUCCESS;
    // progressively create
    std::string cur = "";
    if (p.front() == '/') cur = "/";
    size_t i = (p.front()=='/')?1:0;
    while (i <= p.size()) {
        size_t j = p.find('/', i);
        std::string part = (j==std::string::npos) ? p.substr(i) : p.substr(i, j-i);
        if (!part.empty()) {
            cur = (cur=="/"?"/"+part: (cur.empty()?part:cur+"/"+part));
            if (!afc_exists(afc, cur)) {
                auto r = afc_make_directory(afc, cur.c_str());
                if (r != AFC_E_SUCCESS && r != AFC_E_OBJECT_EXISTS) return r;
            }
        }
        if (j==std::string::npos) break;
        i = j+1;
    }
    return AFC_E_SUCCESS;
}

static std::vector<std::string> afc_listdir(afc_client_t afc, const std::string& path) {
    std::vector<std::string> out;
    char **list = nullptr;
    if (afc_read_directory(afc, path.c_str(), &list) != AFC_E_SUCCESS || !list) return out;
    for (size_t i=0; list[i]; ++i) {
        std::string name = list[i];
        if (name == "." || name == "..") continue;
        out.push_back(name);
    }
    afc_dictionary_free(list);
    return out;
}

// ---------- Task & Config ----------
struct Task { std::string src; std::string dst; bool upload; };

struct Config {
    size_t threads = 4;
    size_t chunk_size = 4 * 1024 * 1024; // bytes
    int retries = 3;
    bool resume = false;
    bool recursive = false;
};

// ---------- TaskQueue ----------
class TaskQueue {
    std::queue<Task> q_;
    std::mutex m_;
    std::condition_variable cv_;
    bool stop_{false};
public:
    void push(Task t){ std::lock_guard<std::mutex> lk(m_); q_.push(std::move(t)); cv_.notify_one(); }
    bool pop(Task &t){ std::unique_lock<std::mutex> lk(m_); cv_.wait(lk, [&]{ return stop_ || !q_.empty(); }); if (stop_ && q_.empty()) return false; t = std::move(q_.front()); q_.pop(); return true; }
    void stop(){ std::lock_guard<std::mutex> lk(m_); stop_ = true; cv_.notify_all(); }
};

// ---------- single-file upload/download ----------
static bool upload_one(AfcSession& s, const Task& t, const Config& cfg) {
    // ensure remote parent dir exists
    std::string parent = dirname_posix(t.dst);
    if (afc_mkdirs(s.afc, parent) != AFC_E_SUCCESS) {
        std::cerr << "[UL] mkdirs failed: " << parent << "\n";
        return false;
    }

    // compute remote start offset for resume
    uint64_t start_off = 0;
    if (cfg.resume) {
        if (auto sz = afc_get_size(s.afc, t.dst)) start_off = *sz;
    }

    // open remote for write
    uint64_t h = 0;
    afc_error_t r = afc_file_open(s.afc, t.dst.c_str(), AFC_FOPEN_WRONLY, &h);
    if (r != AFC_E_SUCCESS) {
        // try create
        r = afc_file_open(s.afc, t.dst.c_str(), AFC_FOPEN_WR, &h);
        if (r != AFC_E_SUCCESS) { std::cerr << "[UL] open remote failed: " << t.dst << "\n"; return false; }
    }
    if (start_off>0) afc_file_seek(s.afc, h, (int64_t)start_off, SEEK_SET);

    // open local file
    std::ifstream in(t.src, std::ios::binary);
    if (!in) { std::cerr << "[UL] open local failed: " << t.src << "\n"; afc_file_close(s.afc, h); return false; }
    in.seekg(0, std::ios::end); uint64_t total = (uint64_t)in.tellg();
    if (start_off > total) start_off = 0; // remote bigger? start over
    in.seekg((std::streamoff)start_off, std::ios::beg);

    std::vector<char> buf; buf.resize(cfg.chunk_size);
    uint64_t done = start_off; auto t0 = std::chrono::steady_clock::now();

    while (in) {
        in.read(buf.data(), (std::streamsize)buf.size());
        std::streamsize rn = in.gcount();
        if (rn <= 0) break;
        const char* p = buf.data(); size_t left = (size_t)rn; int attempt=0;
        while (left>0) {
            uint32_t written = 0;
            r = afc_file_write(s.afc, h, p, (uint32_t)left, &written);
            if (r == AFC_E_SUCCESS) {
                left -= written; p += written; done += written;
            } else {
                if (++attempt > cfg.retries) { std::cerr << "[UL] write failed after retries: " << t.dst << "\n"; afc_file_close(s.afc, h); return false; }
                std::this_thread::sleep_for(std::chrono::milliseconds(100 * attempt));
            }
        }
        auto now=std::chrono::steady_clock::now();
        double sec=std::chrono::duration<double>(now-t0).count();
        double pct = total? (100.0*done/total):0.0;
        std::cerr << "\r[UL] " << t.src << " -> " << t.dst << "  " << (int)pct << "%  "
                  << human_size(done) << "/" << human_size(total) << "  "
                  << (sec>0?human_size((uint64_t)(done/sec)) + "/s":"-") << std::flush;
    }
    afc_file_close(s.afc, h);
    std::cerr << "\n";
    return true;
}

static bool download_one(AfcSession& s, const Task& t, const Config& cfg) {
    // get remote size & type
    auto ifmt = afc_get_ifmt(s.afc, t.src);
    if (!ifmt) { std::cerr << "[DL] remote not found: " << t.src << "\n"; return false; }
    if (*ifmt == std::string("S_IFDIR")) { std::cerr << "[DL] source is directory (use --recursive): " << t.src << "\n"; return false; }
    auto totalOpt = afc_get_size(s.afc, t.src);
    if (!totalOpt) { std::cerr << "[DL] cannot get size: " << t.src << "\n"; return false; }
    uint64_t total = *totalOpt;

    // ensure local parent exists
    fs::create_directories(fs::path(t.dst).parent_path());

    // open remote
    uint64_t h=0; if (afc_file_open(s.afc, t.src.c_str(), AFC_FOPEN_RDONLY, &h) != AFC_E_SUCCESS) { std::cerr << "[DL] open remote failed: " << t.src << "\n"; return false; }

    // local resume
    uint64_t start_off = 0;
    if (cfg.resume && fs::exists(t.dst)) start_off = (uint64_t)fs::file_size(t.dst);

    // open local
    if (!fs::exists(t.dst)) { std::ofstream tmp(t.dst, std::ios::binary); }
    std::fstream out(t.dst, std::ios::in|std::ios::out|std::ios::binary);
    if (!out) { std::cerr << "[DL] open local failed: " << t.dst << "\n"; afc_file_close(s.afc, h); return false; }
    if (start_off > 0) { afc_file_seek(s.afc, h, (int64_t)start_off, SEEK_SET); out.seekp((std::streamoff)start_off, std::ios::beg); }

    std::vector<char> buf; buf.resize(cfg.chunk_size);
    uint64_t done = start_off; auto t0 = std::chrono::steady_clock::now();

    while (done < total) {
        uint32_t want = (uint32_t)std::min<uint64_t>(buf.size(), total - done);
        uint32_t rn = 0;
        auto r = afc_file_read(s.afc, h, buf.data(), want, &rn);
        if (r != AFC_E_SUCCESS) { std::cerr << "[DL] read failed: " << t.src << "\n"; afc_file_close(s.afc, h); return false; }
        if (rn == 0) break;
        out.write(buf.data(), rn);
        if (!out) { std::cerr << "[DL] write local failed: " << t.dst << "\n"; afc_file_close(s.afc, h); return false; }
        done += rn;
        auto now=std::chrono::steady_clock::now(); double sec=std::chrono::duration<double>(now-t0).count();
        double pct = total? (100.0*done/total):0.0;
        std::cerr << "\r[DL] " << t.src << " -> " << t.dst << "  " << (int)pct << "%  "
                  << human_size(done) << "/" << human_size(total) << "  "
                  << (sec>0?human_size((uint64_t)(done/sec)) + "/s":"-") << std::flush;
    }
    afc_file_close(s.afc, h);
    std::cerr << "\n";
    return true;
}

// ---------- recursive expansion ----------
static void expand_upload_tasks_recursive(AfcSession& sess, const std::string& local_src, const std::string& remote_dst, std::vector<Task>& out) {
    fs::path src(local_src);
    if (!fs::exists(src)) { std::cerr << "[UL] not found: " << local_src << "\n"; return; }

    if (fs::is_regular_file(src)) {
        // ensure remote parent dir exists (at transfer time as well)
        out.push_back(Task{ local_src, to_posix_path(remote_dst), true });
        return;
    }

    // directory
    afc_mkdirs(sess.afc, to_posix_path(remote_dst));

    auto base = fs::canonical(src);
    for (auto it = fs::recursive_directory_iterator(base); it != fs::recursive_directory_iterator(); ++it) {
        const fs::path p = it->path();
        auto rel = fs::relative(p, base);
        std::string remote_path = join_posix(remote_dst, rel.generic_string());
        if (fs::is_directory(p)) {
            afc_mkdirs(sess.afc, remote_path);
        } else if (fs::is_regular_file(p)) {
            out.push_back(Task{ p.string(), remote_path, true });
        }
    }
}

static void expand_download_tasks_recursive(AfcSession& sess, const std::string& remote_src, const std::string& local_dst, std::vector<Task>& out) {
    std::string rsrc = to_posix_path(remote_src);
    auto type = afc_get_ifmt(sess.afc, rsrc);
    if (!type) { std::cerr << "[DL] remote not found: " << rsrc << "\n"; return; }

    if (*type == std::string("S_IFREG")) {
        fs::create_directories(fs::path(local_dst).parent_path());
        out.push_back(Task{ rsrc, fs::path(local_dst).string(), false });
        return;
    }

    // directory: create local base dir
    fs::create_directories(local_dst);

    // DFS
    std::function<void(const std::string&, const fs::path&)> dfs = [&](const std::string& rdir, const fs::path& ldir){
        auto entries = afc_listdir(sess.afc, rdir);
        for (const auto& name : entries) {
            std::string rchild = join_posix(rdir, name);
            fs::path lchild = ldir / name;
            auto t = afc_get_ifmt(sess.afc, rchild);
            if (!t) continue;
            if (*t == std::string("S_IFDIR")) {
                fs::create_directories(lchild);
                dfs(rchild, lchild);
            } else {
                fs::create_directories(lchild.parent_path());
                out.push_back(Task{ rchild, lchild.string(), false });
            }
        }
    };

    dfs(rsrc, fs::path(local_dst));
}

// ---------- CLI parsing ----------
struct Cli { std::string mode; Config cfg; std::vector<std::pair<std::string,std::string>> pairs; };

static void usage() {
    std::cerr << "Usage:\n"
              << "  afc_multixfer upload   [options] src:dst [src:dst ...]\n"
              << "  afc_multixfer download [options] src:dst [src:dst ...]\n\n"
              << "Options:\n"
              << "  --threads N      number of worker threads (default 4)\n"
              << "  --chunk-mb M     chunk size in MB (default 4)\n"
              << "  --retries R      write retries on failure (default 3)\n"
              << "  --resume         resume from local/remote offsets\n"
              << "  -r, --recursive  recursively expand directory src\n";
}

static std::optional<Cli> parse_cli(int argc, char** argv) {
    if (argc < 3) { usage(); return std::nullopt; }
    Cli cli; cli.mode = argv[1];
    int i = 2;
    while (i < argc && std::strncmp(argv[i], "-", 1) == 0) {
        std::string a = argv[i++];
        if (a == "--threads" && i<argc) cli.cfg.threads = (size_t)std::stoul(argv[i++]);
        else if (a == "--chunk-mb" && i<argc) cli.cfg.chunk_size = (size_t)std::stoul(argv[i++]) * 1024 * 1024;
        else if (a == "--retries" && i<argc) cli.cfg.retries = std::stoi(argv[i++]);
        else if (a == "--resume") cli.cfg.resume = true;
        else if (a == "-r" || a == "--recursive") cli.cfg.recursive = true;
        else { std::cerr << "Unknown option: " << a << "\n"; usage(); return std::nullopt; }
    }
    if (i >= argc) { usage(); return std::nullopt; }
    for (; i<argc; ++i) {
        std::string pair = argv[i];
        auto pos = pair.find(':');
        if (pos == std::string::npos) { std::cerr << "Bad pair: " << pair << " (expect src:dst)\n"; return std::nullopt; }
        cli.pairs.emplace_back(pair.substr(0,pos), pair.substr(pos+1));
    }
    if (cli.mode != "upload" && cli.mode != "download") { usage(); return std::nullopt; }
    return cli;
}

// ---------- main ----------
int main(int argc, char** argv) {
    auto cliOpt = parse_cli(argc, argv);
    if (!cliOpt) return 2;
    auto cli = *cliOpt;

    // pre-scan session for recursive expansion / mkdirs
    AfcSession scan;
    if (!scan.ok) { std::cerr << "Failed to init AFC session for scanning: " << scan.err << "\n"; return 3; }

    std::vector<Task> tasks;

    if (cli.mode == "upload") {
        for (auto &pr : cli.pairs) {
            std::string lsrc = pr.first; std::string rdst = to_posix_path(pr.second);
            if (cli.cfg.recursive && fs::exists(lsrc) && fs::is_directory(lsrc)) {
                expand_upload_tasks_recursive(scan, lsrc, rdst, tasks);
            } else {
                // single file
                tasks.push_back(Task{ lsrc, rdst, true });
            }
        }
    } else {
        // download
        for (auto &pr : cli.pairs) {
            std::string rsrc = to_posix_path(pr.first); std::string ldst = pr.second;
            if (cli.cfg.recursive) {
                expand_download_tasks_recursive(scan, rsrc, ldst, tasks);
            } else {
                tasks.push_back(Task{ rsrc, ldst, false });
            }
        }
    }

    if (tasks.empty()) { std::cerr << "No tasks to run.\n"; return 0; }

    // worker pool
    TaskQueue q;
    for (auto &t : tasks) q.push(t);

    std::atomic<int> ok{0}, fail{0};
    std::vector<std::thread> workers;
    for (size_t k=0; k<cli.cfg.threads; ++k) {
        workers.emplace_back([&]{
            AfcSession s; if (!s.ok) { std::cerr << "Worker AFC init failed: " << s.err << "\n"; return; }
            Task t;
            while (q.pop(t)) {
                bool r = t.upload ? upload_one(s, t, cli.cfg) : download_one(s, t, cli.cfg);
                if (r) ++ok; else ++fail;
            }
        });
    }

    for (auto &th : workers) th.join();
    q.stop();

    std::cerr << "All done. OK=" << ok << " FAIL=" << fail << "\n";
    return (fail==0)?0:1;
}
